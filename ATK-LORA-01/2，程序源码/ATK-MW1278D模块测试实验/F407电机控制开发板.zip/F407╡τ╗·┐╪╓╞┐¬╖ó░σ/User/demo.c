/**
 ****************************************************************************************************
 * @file        demo.c
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2022-06-21
 * @brief       ATK-MW1278Dģ�����ʵ��
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� F407���������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "demo.h"
#include "./BSP/ATK_MW1278D/atk_mw1278d.h"
#include "./BSP/LED/led.h"
#include "./BSP/KEY/key.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"

/* ATK-MW1278Dģ�����ò������� */
#define DEMO_ADDR       0                               /* �豸��ַ */
#define DEMO_WLRATE     ATK_MW1278D_WLRATE_19K2         /* �������� */
#define DEMO_CHANNEL    0                               /* �ŵ� */
#define DEMO_TPOWER     ATK_MW1278D_TPOWER_20DBM        /* ���书�� */
#define DEMO_WORKMODE   ATK_MW1278D_WORKMODE_NORMAL     /* ����ģʽ */
#define DEMO_TMODE      ATK_MW1278D_TMODE_TT            /* ����ģʽ */
#define DEMO_WLTIME     ATK_MW1278D_WLTIME_1S           /* ����ʱ�� */
#define DEMO_UARTRATE   ATK_MW1278D_UARTRATE_115200BPS  /* UARTͨѶ������ */
#define DEMO_UARTPARI   ATK_MW1278D_UARTPARI_NONE       /* UARTͨѶУ��λ */

/**
 * @brief       ������ʾ��ں���
 * @param       ��
 * @retval      ��
 */
void demo_run(void)
{
    uint8_t ret;
    uint8_t key;
    uint8_t *buf;
    
    /* ��ʼ��ATK-MW1278Dģ�� */
    ret = atk_mw1278d_init(115200);
    if (ret != 0)
    {
        printf("ATK-MW1278D init failed!\r\n");
        while (1)
        {
            LED0_TOGGLE();
            delay_ms(200);
        }
    }
    
    /* ����ATK-MW1278Dģ�� */
    atk_mw1278d_enter_config();
    ret  = atk_mw1278d_addr_config(DEMO_ADDR);
    ret += atk_mw1278d_wlrate_channel_config(DEMO_WLRATE, DEMO_CHANNEL);
    ret += atk_mw1278d_tpower_config(DEMO_TPOWER);
    ret += atk_mw1278d_workmode_config(DEMO_WORKMODE);
    ret += atk_mw1278d_tmode_config(DEMO_TMODE);
    ret += atk_mw1278d_wltime_config(DEMO_WLTIME);
    ret += atk_mw1278d_uart_config(DEMO_UARTRATE, DEMO_UARTPARI);
    atk_mw1278d_exit_config();
    if (ret != 0)
    {
        printf("ATK-MW1278D config failed!\r\n");
        while (1)
        {
            LED0_TOGGLE();
            delay_ms(200);
        }
    }
    
    printf("ATK-MW1278D config succedded!\r\n");
    atk_mw1278d_uart_rx_restart();
    
    while (1)
    {
        key = key_scan(0);
        
        if (key == KEY0_PRES)
        {
            if (atk_mw1278d_free() != ATK_MW1278D_EBUSY)
            {
                atk_mw1278d_uart_printf("This is from ATK-MW1278D.\r\n");
            }
        }
        
        buf = atk_mw1278d_uart_rx_get_frame();
        if (buf != NULL)
        {
            printf("%s", buf);
            atk_mw1278d_uart_rx_restart();
        }
    }
}
